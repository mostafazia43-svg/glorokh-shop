import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { pool, withTx, Tx } from '../src/db';
import { onOrderPaid, onDelivered, approveDue, onRefund } from '../src/modules/commission/commission.service';

class Rollback extends Error {}
// هر تست داخل یک تراکنش اجرا و در پایان برگردانده می‌شود تا دیتابیس تمیز بماند
const inTx = async (fn: (tx: Tx) => Promise<void>) => {
  try { await withTx(async tx => { await fn(tx); throw new Rollback(); }); }
  catch (e) { if (!(e instanceof Rollback)) throw e; }
};

let seq = 0;
const user = async (tx: Tx, sponsor: number | null, aff = true) =>
  (await tx.query(
    `INSERT INTO users(email,referral_code,sponsor_id,is_affiliate) VALUES ($1,$2,$3,$4) RETURNING id`,
    [`t${Date.now()}${seq}@t.dev`, `T${Date.now()}${seq++}`, sponsor, aff])).rows[0].id as number;

async function setup(tx: Tx, net = 1000, status = 'paid') {
  await tx.query('UPDATE commission_rules SET valid_to=now() WHERE product_id IS NULL AND valid_to IS NULL');
  for (const [l, b] of [[1, 500], [2, 300], [3, 200]]) await tx.query('INSERT INTO commission_rules(level,rate_bps) VALUES ($1,$2)', [l, b]);
  const a = await user(tx, null), b = await user(tx, a), c = await user(tx, b), d = await user(tx, c, false);
  const p = (await tx.query(`INSERT INTO products(sku,name,price) VALUES ($1,'x',$2) RETURNING id`, ['S' + Date.now() + seq++, net])).rows[0].id;
  const o = (await tx.query(
    `INSERT INTO orders(buyer_id,status,paid_at,total) VALUES ($1,$2,now(),$3) RETURNING id`, [d, status, net])).rows[0].id;
  const it = (await tx.query(
    `INSERT INTO order_items(order_id,product_id,qty,net_amount) VALUES ($1,$2,1,$3) RETURNING id`, [o, p, net])).rows[0].id;
  return { a, b, c, d, o, it };
}
const comm = async (tx: Tx, o: number) =>
  (await tx.query('SELECT beneficiary_id, level, amount, status FROM commissions WHERE order_id=$1 ORDER BY level', [o])).rows;

test('پورسانت سه‌سطحی: ۵٪ ۳٪ ۲٪ از مبلغ خالص', () => inTx(async tx => {
  const { a, b, c, o } = await setup(tx);
  await onOrderPaid(o, tx);
  const rows = await comm(tx, o);
  assert.deepEqual(rows.map(r => [r.beneficiary_id, r.level, r.amount]), [[c, 1, 50], [b, 2, 30], [a, 3, 20]]);
}));

test('ایدمپوتنسی: تکرار رویداد پورسانت اضافه نمی‌سازد', () => inTx(async tx => {
  const { o } = await setup(tx);
  await onOrderPaid(o, tx); await onOrderPaid(o, tx);
  assert.equal((await comm(tx, o)).length, 3);
}));

test('سفارش pending (پرداخت‌نشده) پورسانت ندارد', () => inTx(async tx => {
  const { o } = await setup(tx, 1000, 'pending');
  await onOrderPaid(o, tx);
  assert.equal((await comm(tx, o)).length, 0);
}));

test('همکار تعلیق‌شده یا غیرهمکار پورسانت نمی‌گیرد', () => inTx(async tx => {
  const { b, o } = await setup(tx);
  await tx.query('UPDATE users SET is_active=false WHERE id=$1', [b]);
  await onOrderPaid(o, tx);
  assert.deepEqual((await comm(tx, o)).map(r => r.level), [1, 3]);
}));

test('تا قبل از تحویل تأیید نمی‌شود؛ بعد از تحویل و پایان مهلت، به کیف پول می‌رود', () => inTx(async tx => {
  await tx.query(`INSERT INTO settings(key,value) VALUES ('hold_days','0') ON CONFLICT (key) DO UPDATE SET value='0'`);
  const { c, o } = await setup(tx);
  await onOrderPaid(o, tx);
  assert.equal(await approveDue(tx), 0);           // هنوز تحویل نشده
  await tx.query(`UPDATE orders SET status='delivered', delivered_at=now() WHERE id=$1`, [o]);
  await onDelivered(o, tx);
  assert.equal(await approveDue(tx), 3);
  const w = await tx.query(`SELECT COALESCE(SUM(amount),0) AS s FROM wallet_entries WHERE user_id=$1`, [c]);
  assert.equal(w.rows[0].s, 50);
}));

test('مرجوعی: پورسانت pending کم می‌شود و پورسانت تأییدشده از کیف پول کسر می‌شود', () => inTx(async tx => {
  await tx.query(`INSERT INTO settings(key,value) VALUES ('hold_days','0') ON CONFLICT (key) DO UPDATE SET value='0'`);
  const { c, o, it } = await setup(tx);
  await onOrderPaid(o, tx);
  await onRefund(it, 500, tx);                      // نصف مبلغ، قبل از تأیید
  assert.deepEqual((await comm(tx, o)).map(r => r.amount), [25, 15, 10]);

  await tx.query(`UPDATE orders SET status='delivered', delivered_at=now() WHERE id=$1`, [o]);
  await onDelivered(o, tx); await approveDue(tx);
  await onRefund(it, 500, tx);                      // نصف دوم، بعد از تأیید
  const w = await tx.query(`SELECT COALESCE(SUM(amount),0) AS s FROM wallet_entries WHERE user_id=$1`, [c]);
  assert.equal(w.rows[0].s, 0);
  assert.ok((await comm(tx, o)).every(r => r.status === 'reversed'));
}));

test('معرف بعد از تعیین تغییر نمی‌کند', () => inTx(async tx => {
  const a = await user(tx, null), b = await user(tx, null), c = await user(tx, a);
  await assert.rejects(() => tx.query('UPDATE users SET sponsor_id=$2 WHERE id=$1', [c, b]), /immutable/);
}));

after(() => pool.end());
