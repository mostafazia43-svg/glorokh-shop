/* گل‌رخ — فرانت‌اند ساده (بدون فریم‌ورک). همه داده‌ها از /api می‌آیند. */
const $ = s => document.querySelector(s);
const fmt = n => Number(n || 0).toLocaleString('fa-AF');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const nl = s => esc(s).replace(/\n/g, '<br>');
const date = d => d && d !== 'infinity' ? new Date(d).toLocaleDateString('fa-AF') : '—';
const STATUS = { pending: ['در انتظار', 'b-warn'], approved: ['تأیید شده', 'b-ok'], reversed: ['برگشت‌خورده', 'b-bad'], paid: ['پرداخت‌شده', 'b-ok'],
  delivered: ['تحویل‌شده', 'b-ok'], refunded: ['مرجوع', 'b-bad'], cancelled: ['لغو', 'b-bad'], requested: ['در انتظار بررسی', 'b-warn'], rejected: ['رد شد', 'b-bad'] };
const badge = s => { const [t, c] = STATUS[s] || [s, 'b-warn']; return `<span class="badge ${c}">${t}</span>`; };

let me = null, cart = JSON.parse(localStorage.getItem('cart') || '[]');
const saveCart = () => { localStorage.setItem('cart', JSON.stringify(cart)); nav(); };

async function api(path, opt = {}) {
  const o = { credentials: 'same-origin', ...opt };
  if (o.body && !(o.body instanceof FormData)) { o.headers = { 'Content-Type': 'application/json' }; o.body = JSON.stringify(o.body); }
  const r = await fetch('/api' + path, o);
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'خطا در ارتباط با سرور');
  return d;
}
function toast(msg, err) {
  const t = document.createElement('div'); t.className = 'toast' + (err ? ' err' : ''); t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), 3000);
}
const act = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };
const val = id => document.getElementById(id)?.value ?? '';

/* ---------- ناوبری ---------- */
function nav() {
  const n = cart.reduce((a, c) => a + c.qty, 0);
  $('#nav').innerHTML = `
    <a class="tab" href="#/">فروشگاه</a>
    <a class="tab" href="#/guide">رهنما</a>
    ${me ? `<a class="tab" href="#/dashboard">پنل همکار</a><a class="tab" href="#/orders">سفارش‌های من</a>` : ''}
    ${me?.role === 'admin' ? `<a class="tab" href="#/admin">ادمین</a>` : ''}
    <a class="tab" href="#/cart">🛒 ${fmt(n)}</a>
    ${me ? `<button class="hdr-btn" onclick="logout()">خروج (${esc(me.name)})</button>` : `<a class="tab" href="#/login">ورود / ثبت‌نام</a>`}`;
}
window.logout = act(async () => { await api('/auth/logout', { method: 'POST' }); me = null; nav(); location.hash = '#/'; });

/* ---------- مسیریابی ---------- */
const routes = { '': shop, product, cart: cartPage, login, register, orders, guide, dashboard, admin };
async function route() {
  const [name, arg] = location.hash.replace(/^#\/?/, '').split('?')[0].split('/');
  $('#app').innerHTML = '<div class="empty">در حال بارگذاری…</div>';
  try { await (routes[name] || shop)(arg); } catch (e) { $('#app').innerHTML = `<div class="box empty">${esc(e.message)}</div>`; }
  scrollTo(0, 0);
}
addEventListener('hashchange', route);
(async () => { try { me = await api('/auth/me'); } catch {} nav(); route(); })();

/* ---------- فروشگاه ---------- */
async function shop() {
  const cat = new URLSearchParams(location.hash.split('?')[1] || '').get('c') || '';
  const [cats, list, ref] = await Promise.all([api('/categories'), api('/products' + (cat ? '?category=' + encodeURIComponent(cat) : '')), api('/auth/referrer')]);
  $('#app').innerHTML = `
    ${ref.name ? `<div class="banner-ref">🤝 شما با لینک «${esc(ref.name)}» وارد شده‌اید؛ خرید شما به نام او ثبت می‌شود.</div>` : ''}
    <div class="hero"><div><h1>مراقبت از پوست،<br>با محصولات اصل و مطمئن</h1>
      <p>ارسال سریع، ضمانت اصالت کالا و مهلت بازگشت.</p>
      <a class="btn ghost" href="#/guide">همکاری در فروش</a></div><div class="blob"></div></div>
    <div class="cats"><a class="chip" href="#/">همه</a>${cats.map(c => `<a class="chip" href="#/?c=${encodeURIComponent(c)}">${esc(c)}</a>`).join('')}</div>
    <div class="grid">${list.map(p => `
      <a class="p" href="#/product/${p.id}"><div class="ph" style="background:var(--soft)">${p.image ? `<img src="${esc(p.image)}" alt="${esc(p.name)}">` : '🌸'}</div>
        <div class="pb"><b>${esc(p.name)}</b><br><small>${esc(p.category)}</small>
        <div class="price"><span>${fmt(p.price)} <small>افغانی</small></span>${p.stock < 1 ? '<span class="badge b-bad">ناموجود</span>' : ''}</div></div></a>`).join('') || '<div class="empty">محصولی ثبت نشده است.</div>'}</div>`;
}

async function product(id) {
  const p = await api('/products/' + id);
  const imgs = p.images;
  const sec = (t, x) => x ? `<div class="sec"><h3>${t}</h3><p>${nl(x)}</p></div>` : '';
  const rate = me?.is_affiliate ? `<button class="earn" onclick="copyLink(${p.id})"><span>🔗 اشتراک این محصول با لینک اختصاصی شما</span><span>کپی</span></button>` : '';
  $('#app').innerHTML = `<div class="gal"><div>
      <div class="main" id="mainImg">${imgs[0] ? `<img src="${esc(imgs[0].url)}" alt="">` : '🌸'}</div>
      <div class="thumbs">${imgs.map((i, k) => `<img src="${esc(i.url)}" class="${k ? '' : 'on'}" onclick="pick(this)">`).join('')}</div></div>
    <div><h2 style="font-size:24px">${esc(p.name)}</h2><small style="color:var(--muted)">${esc(p.category)} · کد: ${esc(p.sku)}</small>
      <p style="margin:10px 0">${esc(p.brief)}</p>
      <div style="font-size:24px;font-weight:700;color:var(--brand)">${fmt(p.price)} <small style="font-size:14px">افغانی</small></div>
      <p class="note">${p.stock > 0 ? `موجودی: ${fmt(p.stock)} عدد` : 'ناموجود'}</p>
      <div class="qty" style="margin:14px 0"><button onclick="q(-1)">−</button><b id="qv">1</b><button onclick="q(1)">+</button>
        <button class="btn" style="width:auto;height:auto;color:#fff;background:var(--brand);padding:10px 22px;font-size:15px" ${p.stock < 1 ? 'disabled' : ''} onclick="addCart(${p.id})">افزودن به سبد</button></div>
      ${rate}</div></div>
    ${sec('توضیحات', p.description)}${sec('روش مصرف', p.usage_instructions)}${sec('ترکیبات و اطلاعات', p.ingredients)}`;
  window._p = p;
}
window.pick = el => { $('#mainImg').innerHTML = `<img src="${el.src}" alt="">`; document.querySelectorAll('.thumbs img').forEach(i => i.classList.toggle('on', i === el)); };
window.q = d => { const e = $('#qv'); e.textContent = Math.min(50, Math.max(1, +e.textContent + d)); };
window.addCart = id => {
  const p = window._p, n = +$('#qv').textContent, row = cart.find(c => c.id === id);
  if (row) row.qty += n; else cart.push({ id, name: p.name, price: p.price, image: p.images[0]?.url || '', qty: n });
  saveCart(); toast('به سبد خرید اضافه شد');
};
window.copyLink = id => { navigator.clipboard?.writeText(`${location.origin}/r/${me.referral_code}?p=${id}`); toast('لینک اختصاصی کپی شد'); };

/* ---------- سبد خرید ---------- */
async function cartPage() {
  const ref = await api('/auth/referrer');
  const sub = cart.reduce((a, c) => a + c.price * c.qty, 0);
  const settings = await api('/shipping').catch(() => ({ shipping_fee: 0 }));
  if (!cart.length) { $('#app').innerHTML = '<div class="box empty">سبد خرید خالی است.</div>'; return; }
  const noRef = me && me.sponsor_name;
  $('#app').innerHTML = `<h2>سبد خرید و ثبت سفارش</h2><div class="cols">
    <div class="box">${cart.map((c, i) => `<div class="cartrow"><div class="ic" style="background:var(--soft)">${c.image ? `<img src="${esc(c.image)}" style="width:56px;height:56px;object-fit:cover;border-radius:12px">` : '🌸'}</div>
        <div><b>${esc(c.name)}</b><br><small style="color:var(--muted)">${fmt(c.price)} × ${fmt(c.qty)}</small></div>
        <div class="qty"><button onclick="cq(${i},-1)">−</button><b>${fmt(c.qty)}</b><button onclick="cq(${i},1)">+</button></div>
        <b>${fmt(c.price * c.qty)}</b></div>`).join('')}
      <label>آدرس تحویل</label><textarea id="addr"></textarea>
      <div class="row2"><div><label>شماره تماس</label><input type="tel" id="phone" dir="ltr" placeholder="07x xxx xxxx"></div>
      <div><label>روش پرداخت</label><select id="pm"><option value="online_test">پرداخت آنلاین (آزمایشی)</option><option value="cod">پرداخت در محل</option></select></div></div>
      ${noRef ? `<div class="sp">🤝 معرفی‌شده توسط: ${esc(me.sponsor_name)}</div>` : `
      <label>کد معرف (اختیاری)</label><input type="text" id="rc" dir="ltr" value="${esc(ref.code || '')}" placeholder="مثلاً SARA2410">
      ${ref.name ? `<div class="sp">🤝 معرفی‌شده توسط: ${esc(ref.name)}</div>` : ''}
      <p class="note">کد معرف بعد از اولین خرید قابل تغییر نیست. کد خودتان پورسانتی ندارد.</p>`}</div>
    <div class="box"><b>خلاصه سفارش</b><div class="sum" style="margin-top:8px">
      <div><span>مبلغ خالص محصولات</span><span>${fmt(sub)}</span></div>
      <div><span>ارسال</span><span>${fmt(settings.shipping_fee)}</span></div>
      <div class="t"><span>مبلغ قابل پرداخت</span><span>${fmt(sub + settings.shipping_fee)} افغانی</span></div></div>
      <p class="note">پورسانت همکاران فقط از «مبلغ خالص محصولات» محاسبه می‌شود.</p>
      <button class="btn" style="width:100%;margin-top:10px" onclick="placeOrder()">ثبت سفارش</button></div></div>`;
}
window.cq = (i, d) => { cart[i].qty += d; if (cart[i].qty < 1) cart.splice(i, 1); saveCart(); cartPage(); };
window.placeOrder = act(async () => {
  if (!me) { location.hash = '#/login'; return toast('ابتدا وارد شوید', true); }
  const r = await api('/orders', { method: 'POST', body: { items: cart.map(c => ({ product_id: c.id, qty: c.qty })),
    address: val('addr'), phone: val('phone'), payment_method: val('pm'), refCode: val('rc') } });
  cart = []; saveCart(); me = await api('/auth/me');
  $('#app').innerHTML = `<div class="box empty"><h2>✅ سفارش #${r.id} ثبت شد</h2><p>مبلغ: ${fmt(r.total)} افغانی</p><a class="btn" href="#/orders">سفارش‌های من</a></div>`;
});

async function orders() {
  if (!me) return (location.hash = '#/login');
  const list = await api('/orders/mine');
  $('#app').innerHTML = `<h2>سفارش‌های من</h2><div class="box"><div class="tw"><table><tr><th>#</th><th>تاریخ</th><th>محصولات</th><th>مبلغ</th><th>وضعیت</th></tr>
    ${list.map(o => `<tr><td>${o.id}</td><td>${date(o.created_at)}</td><td>${(o.items || []).map(i => esc(i.name) + ' ×' + i.qty).join('، ')}</td><td>${fmt(o.total)}</td><td>${badge(o.status)}</td></tr>`).join('') || '<tr><td colspan=5 class="empty">سفارشی ندارید</td></tr>'}</table></div></div>`;
}

/* ---------- ورود / ثبت‌نام ---------- */
async function login() {
  $('#app').innerHTML = `<div class="box" style="max-width:420px;margin:auto"><h2>ورود</h2>
    <label>ایمیل</label><input type="email" id="em" dir="ltr"><label>رمز عبور</label><input type="password" id="pw" dir="ltr">
    <button class="btn" style="width:100%;margin-top:14px" onclick="doLogin()">ورود</button>
    <p class="note">حساب ندارید؟ <a href="#/register" style="color:var(--brand)">ثبت‌نام</a></p></div>`;
}
window.doLogin = act(async () => { me = await api('/auth/login', { method: 'POST', body: { email: val('em'), password: val('pw') } }); me = await api('/auth/me'); nav(); location.hash = '#/'; });
async function register() {
  const ref = await api('/auth/referrer');
  $('#app').innerHTML = `<div class="box" style="max-width:420px;margin:auto"><h2>ثبت‌نام</h2>
    ${ref.name ? `<div class="sp">🤝 معرفی‌شده توسط: ${esc(ref.name)}</div>` : ''}
    <label>نام</label><input type="text" id="nm"><label>ایمیل</label><input type="email" id="em" dir="ltr">
    <label>رمز عبور (حداقل ۸ کاراکتر)</label><input type="password" id="pw" dir="ltr">
    <button class="btn" style="width:100%;margin-top:14px" onclick="doRegister()">ایجاد حساب</button></div>`;
}
window.doRegister = act(async () => { await api('/auth/register', { method: 'POST', body: { name: val('nm'), email: val('em'), password: val('pw') } }); me = await api('/auth/me'); nav(); location.hash = '#/'; });

/* ---------- رهنما ---------- */
async function guide() {
  const faq = [
    ['پورسانت از چه چیزی پرداخت می‌شود؟', 'فقط از خرید قطعی محصول. ثبت‌نام، معرفی افراد یا هزینه عضویت پورسانتی ندارد.'],
    ['سطح ۱، ۲ و ۳ یعنی چه؟', 'سطح ۱ خریداران مستقیم لینک شما، سطح ۲ معرفی‌شده‌های آنان و سطح ۳ معرفی‌شده‌های سطح ۲. بیشتر از ۳ سطح نداریم.'],
    ['پورسانت کی به موجودی من اضافه می‌شود؟', 'پس از پرداخت، «در انتظار» ثبت می‌شود؛ بعد از تحویل کالا و پایان مهلت مرجوعی تأیید و به کیف پول می‌رود.'],
    ['اگر مشتری کالا را مرجوع کند؟', 'پورسانت همان کالا کم یا برگشت داده می‌شود؛ اگر قبلاً تأیید شده باشد، از موجودی بعدی کسر می‌شود.'],
    ['معرف من چه زمانی ثبت می‌شود؟', 'با ورود از لینک همکار، تا ۳۰ روز در مرورگر می‌ماند و هنگام ثبت‌نام (یا اولین خرید) ثبت می‌شود؛ بعد از آن تغییر نمی‌کند.'],
    ['آیا باید هزینه‌ای بپردازم؟', 'خیر. همکاری رایگان است و خرید اجباری وجود ندارد.'],
    ['خرید با کد خودم پورسانت دارد؟', 'خیر؛ خرید با کد خودی پورسانت ندارد و بررسی می‌شود.'],
  ];
  $('#app').innerHTML = `<h2>رهنمای همکاری در فروش</h2>
    <div class="box"><b>مثال:</b> خرید ۱,۰۰۰ افغانی (مبلغ خالص) ← معرف مستقیم ۵۰، سطح ۲ مبلغ ۳۰ و سطح ۳ مبلغ ۲۰ افغانی (نرخ‌های نمونه).
      <p class="note">درآمد وابسته به فروش واقعی است و تضمین‌شده نیست.</p>
      ${me ? (me.is_affiliate ? '<a class="btn" href="#/dashboard">پنل همکار</a>' : '<button class="btn" onclick="joinAff()">همکار فروش شوید (رایگان)</button>') : '<a class="btn" href="#/register">ثبت‌نام</a>'}</div>
    <div class="faq">${faq.map(([q, a]) => `<details><summary>${q}</summary><p>${a}</p></details>`).join('')}</div>`;
}
window.joinAff = act(async () => { await api('/auth/affiliate/join', { method: 'POST' }); me = await api('/auth/me'); nav(); location.hash = '#/dashboard'; });

/* ---------- پنل همکار ---------- */
async function dashboard() {
  if (!me) return (location.hash = '#/login');
  const s = await api('/affiliate/summary');
  if (!s.is_affiliate) { $('#app').innerHTML = `<div class="box empty"><h2>هنوز همکار فروش نیستید</h2><button class="btn" onclick="joinAff()">فعال‌سازی رایگان</button></div>`; return; }
  const link = `${location.origin}/r/${s.referral_code}`;
  $('#app').innerHTML = `<h2>سلام ${esc(me.name)} 👋</h2>
    <div class="stats"><div class="stat"><span>موجودی قابل برداشت</span><b>${fmt(s.balance)} افغانی</b></div>
      <div class="stat"><span>در انتظار تأیید</span><b>${fmt(s.pending)} افغانی</b></div>
      <div class="stat"><span>مجموع کسب‌درآمد</span><b>${fmt(s.earned)} افغانی</b></div>
      <div class="stat"><span>شبکه (سطح ۱/۲/۳)</span><b>${s.network.map(fmt).join(' / ')}</b></div></div>
    <div class="box"><b>لینک اختصاصی شما</b><div class="link" style="margin-top:10px"><input type="text" id="lk" readonly value="${esc(link)}" style="direction:ltr">
      <button class="btn" onclick="navigator.clipboard?.writeText($('#lk').value);toast('کپی شد')">کپی لینک</button></div>
      <p class="note">برای لینک هر محصول، صفحه محصول را باز کنید و «اشتراک» را بزنید.</p></div>
    <div class="cols"><div class="box"><b>شبکه شما (نام‌ها نیمه‌پنهان)</b><div style="margin-top:8px">
      ${s.tree.map(t => `<div class="lv" style="margin-inline-start:${(t.lvl - 1) * 20}px"><div class="dot l${t.lvl}">${t.lvl}</div><div style="flex:1">${esc(t.name)}</div><span>${fmt(t.sales)}</span></div>`).join('') || '<p class="note">هنوز کسی از لینک شما وارد نشده است.</p>'}</div></div>
    <div class="box"><b>درخواست برداشت</b><label>مبلغ (حداقل ${fmt(s.min_payout)})</label><input type="number" id="pa">
      <label>روش</label><select id="pmth"><option>حواله بانکی</option><option>کیف پول موبایل</option></select>
      <label>شماره حساب / کیف پول</label><input type="text" id="pac" dir="ltr">
      <button class="btn" style="width:100%;margin-top:12px" onclick="reqPayout()">ثبت درخواست</button></div></div>
    <div class="box"><b>آخرین پورسانت‌ها</b><div class="tw"><table><tr><th>سفارش</th><th>سطح</th><th>مبلغ خالص</th><th>نرخ</th><th>پورسانت</th><th>وضعیت</th><th>تأیید در</th></tr>
      ${s.commissions.map(c => `<tr><td>#${c.order_id}</td><td>${c.level}</td><td>${fmt(c.base_amount)}</td><td>${c.rate_bps / 100}٪</td><td>${fmt(c.amount)}</td><td>${badge(c.status)}</td><td>${c.status === 'pending' ? date(c.approve_after) : '—'}</td></tr>`).join('') || '<tr><td colspan=7 class="empty">هنوز پورسانتی ندارید</td></tr>'}</table></div></div>
    <div class="cols"><div class="box"><b>تاریخچه کیف پول</b><div class="tw"><table>${s.wallet.map(w => `<tr><td>${date(w.created_at)}</td><td>${{ commission: 'پورسانت', clawback: 'کسر مرجوعی', payout: 'برداشت', adjust: 'اصلاح' }[w.type]}</td><td class="${w.amount < 0 ? 'neg' : 'pos'}">${fmt(w.amount)}</td></tr>`).join('') || '<tr><td class="empty">خالی</td></tr>'}</table></div></div>
    <div class="box"><b>برداشت‌ها</b><div class="tw"><table>${s.payouts.map(p => `<tr><td>${date(p.created_at)}</td><td>${esc(p.method)}</td><td>${fmt(p.amount)}</td><td>${badge(p.status)}</td></tr>`).join('') || '<tr><td class="empty">خالی</td></tr>'}</table></div></div></div>`;
}
window.reqPayout = act(async () => { await api('/affiliate/payouts', { method: 'POST', body: { amount: val('pa'), method: val('pmth'), account: val('pac') } }); toast('درخواست ثبت شد'); dashboard(); });

/* ---------- پنل ادمین ---------- */
let admTab = 'products';
const ADM = [['products', 'محصولات'], ['orders', 'سفارش‌ها'], ['commissions', 'پورسانت‌ها'], ['payouts', 'برداشت‌ها'], ['rules', 'نرخ‌ها و تنظیمات'], ['users', 'همکاران'], ['flags', 'ضدتقلب'], ['audit', 'لاگ']];
async function admin() {
  if (me?.role !== 'admin') throw new Error('دسترسی ندارید');
  const st = await api('/admin/stats');
  $('#app').innerHTML = `<h2>پنل مدیریت</h2>
    <div class="stats"><div class="stat"><span>فروش (خالص)</span><b>${fmt(st.sales)}</b></div><div class="stat"><span>سفارش‌ها</span><b>${fmt(st.orders)}</b></div>
      <div class="stat"><span>پورسانت تأییدشده</span><b>${fmt(st.commissions_approved)}</b></div><div class="stat"><span>پورسانت در انتظار</span><b>${fmt(st.commissions_pending)}</b></div>
      <div class="stat"><span>همکاران</span><b>${fmt(st.affiliates)}</b></div><div class="stat"><span>برداشت باز / پرچم باز</span><b>${fmt(st.payouts_open)} / ${fmt(st.flags_open)}</b></div></div>
    <div class="atabs">${ADM.map(([k, t]) => `<button class="atab ${k === admTab ? 'on' : ''}" onclick="admGo('${k}')">${t}</button>`).join('')}</div><div id="adm"></div>`;
  await admViews[admTab]();
}
window.admGo = act(async k => { admTab = k; await admin(); });
const A = (path, method = 'POST', body) => api('/admin' + path, { method, body });
const admViews = {
  async products() {
    const list = await api('/admin/products');
    $('#adm').innerHTML = `<div class="box"><div class="tools"><b style="flex:1;align-self:center">محصولات</b><button class="btn" onclick="editProduct(null)">+ محصول جدید</button></div>
      <div id="pform"></div><div class="tw"><table><tr><th></th><th>نام</th><th>کد</th><th>دسته</th><th>قیمت</th><th>موجودی</th><th>عکس</th><th>وضعیت</th><th></th></tr>
      ${list.map(p => `<tr><td>${p.image ? `<img src="${esc(p.image)}" width="40" height="40" style="object-fit:cover;border-radius:8px">` : ''}</td><td>${esc(p.name)}</td><td>${esc(p.sku)}</td><td>${esc(p.category)}</td><td>${fmt(p.price)}</td><td>${fmt(p.stock)}</td><td>${p.image_count}</td>
      <td>${p.is_active ? badge('paid').replace('پرداخت‌شده', 'فعال') : '<span class="badge b-bad">غیرفعال</span>'}</td><td><button class="sm" onclick="editProduct(${p.id})">ویرایش</button></td></tr>`).join('')}</table></div></div>`;
  },
  async orders() {
    const list = await api('/admin/orders');
    $('#adm').innerHTML = `<div class="box"><div class="tw"><table><tr><th>#</th><th>خریدار</th><th>معرف</th><th>محصولات</th><th>مبلغ</th><th>پورسانت کل</th><th>وضعیت</th><th>عملیات</th></tr>
      ${list.map(o => `<tr><td>${o.id}</td><td>${esc(o.buyer)}<br><small>${esc(o.phone)}</small></td><td>${esc(o.sponsor || '—')}</td>
      <td>${(o.items || []).map(i => `${esc(i.name)} ×${i.qty}${i.refunded < i.net ? ` <button class="sm no" onclick="refund(${o.id},${i.id})">مرجوع</button>` : ' (مرجوع)'}`).join('<br>')}</td>
      <td>${fmt(o.total)}</td><td>${fmt(o.commission_total)}</td><td>${badge(o.status)}</td>
      <td>${['pending', 'paid'].includes(o.status) ? `<button class="sm ok" onclick="deliver(${o.id})">${o.status === 'pending' ? 'تحویل + دریافت پول' : 'تحویل شد'}</button>` : ''}</td></tr>`).join('')}</table></div></div>`;
  },
  async commissions() {
    const list = await api('/admin/commissions');
    $('#adm').innerHTML = `<div class="box"><div class="tools"><b style="flex:1;align-self:center">دفتر پورسانت</b><button class="btn" onclick="approveNow()">تأیید پورسانت‌های سررسید</button></div>
      <div class="tw"><table><tr><th>سفارش</th><th>همکار</th><th>سطح</th><th>مبلغ خالص</th><th>نرخ</th><th>پورسانت</th><th>وضعیت</th><th>تأیید در</th></tr>
      ${list.map(c => `<tr><td>#${c.order_id}</td><td>${esc(c.beneficiary)}</td><td>${c.level}</td><td>${fmt(c.base_amount)}</td><td>${c.rate_bps / 100}٪</td><td>${fmt(c.amount)}</td><td>${badge(c.status)}</td><td>${c.status === 'pending' ? date(c.approve_after) : '—'}</td></tr>`).join('')}</table></div></div>`;
  },
  async payouts() {
    const list = await api('/admin/payouts');
    $('#adm').innerHTML = `<div class="box"><div class="tw"><table><tr><th>همکار</th><th>مبلغ</th><th>روش</th><th>حساب</th><th>موجودی فعلی</th><th>وضعیت</th><th></th></tr>
      ${list.map(p => `<tr><td>${esc(p.user_name)}</td><td>${fmt(p.amount)}</td><td>${esc(p.method)}</td><td dir="ltr">${esc(p.account)}</td><td>${fmt(p.balance)}</td><td>${badge(p.status)}</td>
      <td>${p.status === 'requested' ? `<button class="sm ok" onclick="payout(${p.id},'approve')">پرداخت شد</button> <button class="sm no" onclick="payout(${p.id},'reject')">رد</button>` : ''}</td></tr>`).join('')}</table></div></div>`;
  },
  async rules() {
    const [r, s] = await Promise.all([api('/admin/rules'), api('/admin/settings')]);
    $('#adm').innerHTML = `<div class="cols"><div class="box"><b>نرخ پورسانت (٪)</b>
      ${[1, 2, 3].map(l => `<div class="rate"><span>سطح ${l}</span><input type="number" step="0.5" min="0" class="rt" value="${r.rates[l - 1] / 100}"></div>`).join('')}
      <p class="note">سقف مجموع سه سطح: ${r.cap_bps / 100}٪ (از «سقف» در تنظیمات)</p><button class="btn" style="width:100%" onclick="saveRules()">ذخیره نسخه جدید</button>
      <ul class="audit">${r.history.slice(0, 6).map(h => `<li>سطح ${h.level}: ${h.rate_bps / 100}٪ <small>از ${date(h.valid_from)}${h.valid_to ? ' تا ' + date(h.valid_to) : ' (فعلی)'}</small></li>`).join('')}</ul></div>
      <div class="box"><b>تنظیمات</b>
      <div class="rate"><span>مهلت مرجوعی (روز)</span><input type="number" id="s_hold" value="${esc(s.hold_days)}"></div>
      <div class="rate"><span>حداقل برداشت</span><input type="number" id="s_min" value="${esc(s.min_payout)}"></div>
      <div class="rate"><span>هزینه ارسال</span><input type="number" id="s_ship" value="${esc(s.shipping_fee)}"></div>
      <div class="rate"><span>سقف مجموع نرخ‌ها (صدم درصد: ۱۵۰۰ = ۱۵٪)</span><input type="number" id="s_cap" value="${esc(s.max_total_bps)}"></div>
      ${+s.hold_days < 7 ? '<p class="note" style="color:var(--warn)">⚠ مهلت مرجوعی کوتاه است (حالت آزمایشی). برای سایت واقعی مثلاً ۱۴ روز بگذارید.</p>' : ''}
      <button class="btn" style="width:100%" onclick="saveSettings()">ذخیره تنظیمات</button></div></div>`;
  },
  async users() {
    const list = await api('/admin/users');
    $('#adm').innerHTML = `<div class="box"><div class="tw"><table><tr><th>نام</th><th>ایمیل</th><th>نقش</th><th>معرف</th><th>مستقیم</th><th>خرید شخصی</th><th>وضعیت</th><th></th></tr>
      ${list.map(u => `<tr><td>${esc(u.name)}${u.is_affiliate ? ' 🤝' : ''}</td><td dir="ltr">${esc(u.email)}</td><td>${u.role}</td><td>${esc(u.sponsor || '—')}</td><td>${u.direct}</td><td>${fmt(u.own_sales)}</td>
      <td>${u.is_active ? '<span class="badge b-ok">فعال</span>' : '<span class="badge b-bad">تعلیق</span>'}</td>
      <td>${u.role === 'admin' ? '' : `<button class="sm ${u.is_active ? 'no' : 'ok'}" onclick="setActive(${u.id},${!u.is_active})">${u.is_active ? 'تعلیق' : 'فعال‌سازی'}</button>`}</td></tr>`).join('')}</table></div></div>`;
  },
  async flags() {
    const list = await api('/admin/flags');
    $('#adm').innerHTML = `<div class="box"><div class="tw"><table><tr><th>شدت</th><th>نوع</th><th>کاربر</th><th>جزئیات</th><th>وضعیت</th><th></th></tr>
      ${list.map(f => `<tr><td><span class="sev s-${f.severity[0]}"></span>${f.severity}</td><td>${esc(f.type)}</td><td>${esc(f.user_name || '—')}</td><td>${esc(f.detail)}</td><td>${f.status}</td>
      <td>${f.status === 'open' ? `<button class="sm" onclick="resolveFlag(${f.id})">بسته شد</button>` : ''}</td></tr>`).join('') || '<tr><td class="empty">پرچمی نیست</td></tr>'}</table></div></div>`;
  },
  async audit() {
    const list = await api('/admin/audit');
    $('#adm').innerHTML = `<div class="box"><ul class="audit">${list.map(a => `<li>${esc(a.admin || '—')}: <b>${esc(a.action)}</b> ${esc(a.detail)} <small>· ${date(a.created_at)}</small></li>`).join('')}</ul></div>`;
  },
};
const reload = () => admViews[admTab]();
window.deliver = act(async id => { await A(`/orders/${id}/deliver`); toast('ثبت شد'); reload(); });
window.refund = act(async (o, i) => { if (!confirm('این آیتم مرجوع شود؟')) return; await A(`/orders/${o}/refund`, 'POST', { item_id: i }); toast('مرجوع شد'); reload(); });
window.approveNow = act(async () => { const r = await A('/commissions/approve-due'); toast(`${fmt(r.approved)} پورسانت تأیید شد`); reload(); });
window.payout = act(async (id, a) => { await A(`/payouts/${id}/${a}`); reload(); });
window.setActive = act(async (id, v) => { await A(`/users/${id}/active`, 'POST', { active: v }); reload(); });
window.resolveFlag = act(async id => { await A(`/flags/${id}/resolve`); reload(); });
window.saveRules = act(async () => { await A('/rules', 'PUT', { rates: [...document.querySelectorAll('.rt')].map(e => Math.round(+e.value * 100)) }); toast('نرخ‌ها ذخیره شد'); reload(); });
window.saveSettings = act(async () => { await A('/settings', 'PUT', { hold_days: val('s_hold'), min_payout: val('s_min'), shipping_fee: val('s_ship'), max_total_bps: val('s_cap') }); toast('ذخیره شد'); reload(); });

/* ----- فرم محصول + آپلود عکس ----- */
window.editProduct = act(async id => {
  const p = id ? await api('/admin/products/' + id) : { name: '', sku: '', category: '', price: '', stock: 0, brief: '', description: '', usage_instructions: '', ingredients: '', commission_eligible: true, is_active: true, images: [] };
  const f = (k, label, type = 'text') => `<div><label>${label}</label><input type="${type}" id="f_${k}" value="${esc(p[k])}"></div>`;
  const t = (k, label) => `<label>${label}</label><textarea id="f_${k}">${esc(p[k])}</textarea>`;
  $('#pform').innerHTML = `<div class="sec"><h3>${id ? 'ویرایش محصول' : 'محصول جدید'}</h3>
    <div class="row2">${f('name', 'نام محصول')}${f('sku', 'کد کالا (یکتا)')}${f('category', 'دسته‌بندی')}${f('price', 'قیمت (افغانی)', 'number')}${f('stock', 'موجودی', 'number')}${f('brief', 'توضیح کوتاه')}</div>
    ${t('description', 'توضیحات کامل')}${t('usage_instructions', 'روش مصرف')}${t('ingredients', 'ترکیبات و اطلاعات')}
    <div class="chk"><input type="checkbox" id="f_commission_eligible" ${p.commission_eligible ? 'checked' : ''}><span>مشمول پورسانت</span></div>
    <div class="chk"><input type="checkbox" id="f_is_active" ${p.is_active ? 'checked' : ''}><span>نمایش در فروشگاه</span></div>
    <label>افزودن عکس (jpg / png / webp — تا ۸ فایل، هر کدام حداکثر ۵ مگابایت)</label><input type="file" id="f_files" accept="image/jpeg,image/png,image/webp" multiple>
    ${p.images.length ? `<div class="imgs">${p.images.map((i, k) => `<div><img src="${esc(i.url)}"><br>${k ? `<button class="sm" onclick="cover(${i.id},${id})">شاخص</button> ` : '<small>شاخص</small> '}<button class="sm no" onclick="delImg(${i.id},${id})">حذف</button></div>`).join('')}</div>` : ''}
    <button class="btn" onclick="saveProduct(${id})">ذخیره</button> <button class="btn ghost" onclick="$('#pform').innerHTML=''">بستن</button></div>`;
  $('#pform').scrollIntoView({ behavior: 'smooth' });
});
window.saveProduct = act(async id => {
  const b = {}; ['name', 'sku', 'category', 'price', 'stock', 'brief', 'description', 'usage_instructions', 'ingredients'].forEach(k => b[k] = val('f_' + k));
  b.commission_eligible = $('#f_commission_eligible').checked; b.is_active = $('#f_is_active').checked;
  const p = id ? await A('/products/' + id, 'PUT', b) : await A('/products', 'POST', b);
  const files = $('#f_files').files;
  if (files.length) { const fd = new FormData(); [...files].forEach(x => fd.append('images', x)); await api(`/admin/products/${p.id}/images`, { method: 'POST', body: fd }); }
  toast('محصول ذخیره شد'); await reload(); editProduct(p.id);
});
window.delImg = act(async (iid, pid) => { await A('/images/' + iid, 'DELETE'); editProduct(pid); reload(); });
window.cover = act(async (iid, pid) => { await A(`/images/${iid}/cover`); reload(); editProduct(pid); });
