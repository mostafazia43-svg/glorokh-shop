CREATE TABLE users (
  id            BIGSERIAL PRIMARY KEY,
  name          TEXT NOT NULL DEFAULT '',
  email         TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL DEFAULT '',
  role          TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
  referral_code TEXT UNIQUE NOT NULL,
  sponsor_id    BIGINT REFERENCES users(id),
  is_affiliate  BOOLEAN NOT NULL DEFAULT false,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  signup_ip     TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (sponsor_id IS NULL OR sponsor_id <> id)
);
CREATE INDEX ON users(sponsor_id);

-- معرف فقط یک‌بار (NULL → مقدار) قابل تعیین است و بعد تغییرناپذیر می‌شود
CREATE FUNCTION forbid_sponsor_change() RETURNS trigger AS $$
BEGIN
  IF OLD.sponsor_id IS NOT NULL AND NEW.sponsor_id IS DISTINCT FROM OLD.sponsor_id THEN
    RAISE EXCEPTION 'sponsor_id is immutable';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
CREATE TRIGGER users_sponsor_immutable BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION forbid_sponsor_change();

CREATE TABLE products (
  id                  BIGSERIAL PRIMARY KEY,
  sku                 TEXT UNIQUE NOT NULL,
  name                TEXT NOT NULL,
  category            TEXT NOT NULL DEFAULT 'سایر',
  brief               TEXT NOT NULL DEFAULT '',
  description         TEXT NOT NULL DEFAULT '',
  usage_instructions  TEXT NOT NULL DEFAULT '',
  ingredients         TEXT NOT NULL DEFAULT '',
  price               BIGINT NOT NULL CHECK (price >= 0),
  stock               INT NOT NULL DEFAULT 0 CHECK (stock >= 0),
  commission_eligible BOOLEAN NOT NULL DEFAULT true,
  is_active           BOOLEAN NOT NULL DEFAULT true,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product_images (
  id         BIGSERIAL PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url        TEXT NOT NULL,
  sort       INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON product_images(product_id, sort);

CREATE TABLE orders (
  id             BIGSERIAL PRIMARY KEY,
  buyer_id       BIGINT NOT NULL REFERENCES users(id),
  status         TEXT NOT NULL CHECK (status IN ('pending','paid','delivered','refunded','cancelled')),
  payment_method TEXT NOT NULL DEFAULT 'online_test',
  address        TEXT NOT NULL DEFAULT '',
  phone          TEXT NOT NULL DEFAULT '',
  paid_at        TIMESTAMPTZ,
  delivered_at   TIMESTAMPTZ,
  shipping       BIGINT NOT NULL DEFAULT 0,
  tax            BIGINT NOT NULL DEFAULT 0,
  total          BIGINT NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON orders(buyer_id);

CREATE TABLE order_items (
  id              BIGSERIAL PRIMARY KEY,
  order_id        BIGINT NOT NULL REFERENCES orders(id),
  product_id      BIGINT NOT NULL REFERENCES products(id),
  qty             INT NOT NULL CHECK (qty > 0),
  net_amount      BIGINT NOT NULL,
  refunded_amount BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX ON order_items(order_id);

CREATE TABLE commission_rules (
  id         BIGSERIAL PRIMARY KEY,
  level      SMALLINT NOT NULL CHECK (level BETWEEN 1 AND 3),
  product_id BIGINT REFERENCES products(id),
  rate_bps   INT NOT NULL CHECK (rate_bps BETWEEN 0 AND 10000),
  valid_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  valid_to   TIMESTAMPTZ
);

CREATE TABLE commissions (
  id             BIGSERIAL PRIMARY KEY,
  order_id       BIGINT NOT NULL REFERENCES orders(id),
  order_item_id  BIGINT NOT NULL REFERENCES order_items(id),
  beneficiary_id BIGINT NOT NULL REFERENCES users(id),
  level          SMALLINT NOT NULL CHECK (level BETWEEN 1 AND 3),
  base_amount    BIGINT NOT NULL,
  rate_bps       INT NOT NULL,
  amount         BIGINT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','reversed','paid')),
  approve_after  TIMESTAMPTZ NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (order_item_id, beneficiary_id, level)
);
CREATE INDEX ON commissions(beneficiary_id, status);
CREATE INDEX ON commissions(status, approve_after);

CREATE TABLE wallet_entries (
  id         BIGSERIAL PRIMARY KEY,
  user_id    BIGINT NOT NULL REFERENCES users(id),
  amount     BIGINT NOT NULL,
  type       TEXT NOT NULL CHECK (type IN ('commission','clawback','payout','adjust')),
  ref_id     BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON wallet_entries(user_id);
CREATE UNIQUE INDEX wallet_commission_once ON wallet_entries(ref_id) WHERE type = 'commission';

CREATE TABLE payouts (
  id         BIGSERIAL PRIMARY KEY,
  user_id    BIGINT NOT NULL REFERENCES users(id),
  amount     BIGINT NOT NULL CHECK (amount > 0),
  method     TEXT NOT NULL DEFAULT '',
  account    TEXT NOT NULL DEFAULT '',
  status     TEXT NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','paid','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE fraud_flags (
  id         BIGSERIAL PRIMARY KEY,
  type       TEXT NOT NULL,
  severity   TEXT NOT NULL CHECK (severity IN ('high','medium','low')),
  user_id    BIGINT REFERENCES users(id),
  detail     TEXT NOT NULL DEFAULT '',
  status     TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE audit_log (
  id         BIGSERIAL PRIMARY KEY,
  admin_id   BIGINT REFERENCES users(id),
  action     TEXT NOT NULL,
  detail     TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
