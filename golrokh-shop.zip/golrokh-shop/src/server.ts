import express, { NextFunction, Request, Response } from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { PORT, COOKIE_SECURE, REF_COOKIE_MS } from './config';
import { pool } from './db';
import { HttpError, wrap } from './http';
import { loadUser } from './middleware/auth';
import authRoutes from './modules/auth/auth.routes';
import { publicRoutes, UPLOAD_DIR } from './modules/catalog/catalog.routes';
import ordersRoutes from './modules/orders/orders.routes';
import affiliateRoutes from './modules/affiliate/affiliate.routes';
import adminRoutes from './modules/admin/admin.routes';

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(loadUser);

app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));
app.use(express.static(path.join(process.cwd(), 'public')));

// لینک ارجاع: /r/CODE یا /r/CODE?p=محصول  → کوکی ۳۰ روزه
app.get('/r/:code', wrap(async (req, res) => {
  const code = String(req.params.code).toUpperCase();
  const u = (await pool.query('SELECT id FROM users WHERE referral_code=$1 AND is_active', [code])).rows[0];
  if (u && req.user?.id !== u.id) {
    res.cookie('ref', code, { maxAge: REF_COOKIE_MS, httpOnly: true, sameSite: 'lax', secure: COOKIE_SECURE });
  }
  const p = Number(req.query.p);
  res.redirect(Number.isInteger(p) && p > 0 ? `/#/product/${p}` : '/');
}));

app.use('/api/auth', authRoutes);
app.use('/api/affiliate', affiliateRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', publicRoutes);

app.use('/api', (_req, _res, next) => next(new HttpError(404, 'پیدا نشد')));
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err?.name === 'MulterError') return res.status(400).json({ error: 'خطا در آپلود: ' + err.message });
  console.error(err);
  res.status(500).json({ error: 'خطای داخلی سرور' });
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`✔ http://localhost:${PORT}`));
}
export default app;
