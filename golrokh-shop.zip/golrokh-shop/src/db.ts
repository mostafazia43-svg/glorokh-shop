import 'dotenv/config';
import { Pool, PoolClient, types } from 'pg';

types.setTypeParser(20, Number);   // BIGINT → number
types.setTypeParser(1700, Number); // NUMERIC (SUM) → number

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export type Tx = PoolClient;
export type Q = { query: (text: string, params?: any[]) => Promise<{ rows: any[]; rowCount: number | null }> };

export async function withTx<T>(fn: (tx: Tx) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    await c.query('ROLLBACK');
    throw e;
  } finally {
    c.release();
  }
}

export async function getSetting(db: Q, key: string, def: string): Promise<string> {
  const r = await db.query('SELECT value FROM settings WHERE key=$1', [key]);
  return r.rows[0]?.value ?? def;
}

export const audit = (db: Q, adminId: number, action: string, detail = '') =>
  db.query('INSERT INTO audit_log(admin_id,action,detail) VALUES ($1,$2,$3)', [adminId, action, detail]);

export const flag = (db: Q, type: string, severity: 'high' | 'medium' | 'low', userId: number | null, detail: string) =>
  db.query('INSERT INTO fraud_flags(type,severity,user_id,detail) VALUES ($1,$2,$3,$4)', [type, severity, userId, detail]);
