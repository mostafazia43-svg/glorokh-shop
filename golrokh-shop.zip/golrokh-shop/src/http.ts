import { Request, Response, RequestHandler } from 'express';

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
export const wrap = (fn: (req: Request, res: Response) => Promise<unknown>): RequestHandler =>
  (req, res, next) => { fn(req, res).catch(next); };

export const num = (v: unknown, name: string, min = 0) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min) throw new HttpError(400, `مقدار «${name}» نامعتبر است`);
  return Math.floor(n);
};
