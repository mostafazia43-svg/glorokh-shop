import { Request, Response, NextFunction, RequestHandler } from 'express';
import jwt from 'jsonwebtoken';
import { JWT_SECRET, COOKIE_SECURE } from '../config';
import { pool } from '../db';
import { HttpError } from '../http';

declare global {
  namespace Express { interface Request { user?: { id: number; role: string } } }
}

export const sign = (u: { id: number; role: string }) => jwt.sign(u, JWT_SECRET, { expiresIn: '30d' });

export const setAuthCookie = (res: Response, u: { id: number; role: string }) =>
  res.cookie('token', sign(u), { httpOnly: true, sameSite: 'lax', secure: COOKIE_SECURE, maxAge: 30 * 86400e3 });

export const loadUser = async (req: Request, _res: Response, next: NextFunction) => {
  try {
    const t = req.cookies?.token;
    if (t) {
      const p = jwt.verify(t, JWT_SECRET) as { id: number };
      const r = await pool.query('SELECT id, role FROM users WHERE id=$1 AND is_active', [p.id]);
      if (r.rows[0]) req.user = r.rows[0];
    }
  } catch { /* توکن نامعتبر = مهمان */ }
  next();
};

export const requireUser: RequestHandler = (req, _res, next) =>
  req.user ? next() : next(new HttpError(401, 'ابتدا وارد شوید'));

export const requireAdmin: RequestHandler = (req, _res, next) =>
  req.user?.role === 'admin' ? next() : next(new HttpError(403, 'دسترسی ندارید'));
