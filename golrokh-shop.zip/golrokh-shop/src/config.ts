import 'dotenv/config';

export const PORT = Number(process.env.PORT ?? 3000);
export const JWT_SECRET = process.env.JWT_SECRET ?? 'dev-secret-change-me';
export const COOKIE_SECURE = process.env.COOKIE_SECURE === 'true';
export const REF_COOKIE_MS = 30 * 24 * 3600 * 1000; // لینک ارجاع ۳۰ روز در مرورگر می‌ماند

if (process.env.NODE_ENV === 'production' && JWT_SECRET.startsWith('change-me')) {
  throw new Error('JWT_SECRET must be set in production');
}
