import { pool, withTx } from '../db';
import { approveDue } from '../modules/commission/commission.service';

withTx(approveDue).then(n => console.log('approved:', n)).finally(() => pool.end());
