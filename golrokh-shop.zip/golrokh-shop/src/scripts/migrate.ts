import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';
import { pool, withTx } from '../db';

(async () => {
  await pool.query('CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY)');
  const dir = join(process.cwd(), 'migrations');
  for (const f of readdirSync(dir).filter(f => f.endsWith('.sql')).sort()) {
    if ((await pool.query('SELECT 1 FROM schema_migrations WHERE name=$1', [f])).rowCount) continue;
    await withTx(async tx => {
      await tx.query(readFileSync(join(dir, f), 'utf8'));
      await tx.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
    });
    console.log('applied', f);
  }
  await pool.end();
})().catch(e => { console.error(e); process.exit(1); });
