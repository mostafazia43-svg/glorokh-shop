import bcrypt from 'bcryptjs';
import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';
import { pool } from '../db';

const ADMIN_EMAIL = process.env.SEED_ADMIN_EMAIL ?? 'admin@example.com';
const ADMIN_PASS = process.env.SEED_ADMIN_PASSWORD ?? 'Admin12345';
const DEMO_PASS = 'Test12345';

const products = [
  { sku: 'CR-001', name: 'کرم مرطوب‌کننده', category: 'مراقبت پوست', price: 480, stock: 50, emoji: '🧴', bg: '#fde8ee',
    brief: 'مرطوب‌کننده سبک برای استفاده روزانه',
    description: 'کرم مرطوب‌کننده با بافت سبک که به‌سرعت جذب پوست می‌شود و تا ۲۴ ساعت نرمی را حفظ می‌کند.',
    usage: 'هر صبح و شب بعد از شستن صورت، مقدار کمی کرم را روی پوست پخش و ماساژ دهید.\nاز تماس با چشم خودداری کنید.',
    ingredients: 'آب، گلیسیرین، روغن جوجوبا، ویتامین E، عصاره آلوورا' },
  { sku: 'LP-002', name: 'رژ لب مات', category: 'آرایش', price: 320, stock: 80, emoji: '💄', bg: '#fbe0e0',
    brief: 'ماندگاری بالا، بدون خشکی',
    description: 'رژ لب مات با رنگدانه بالا و فرمول مرطوب‌کننده.',
    usage: 'ابتدا لب‌ها را تمیز کنید، سپس از وسط لب شروع کرده و به گوشه‌ها بکشید.',
    ingredients: 'موم، روغن کرچک، رنگدانه‌های معدنی، ویتامین E' },
  { sku: 'SR-003', name: 'سرم ویتامین C', category: 'مراقبت پوست', price: 790, stock: 30, emoji: '💧', bg: '#fff0d9',
    brief: 'روشن‌کننده و ضد لکه',
    description: 'سرم ویتامین C با غلظت ۱۰٪ برای شفافیت و یکنواختی رنگ پوست.',
    usage: 'شب‌ها ۳ تا ۴ قطره روی پوست تمیز بزنید. روز بعد حتماً از ضدآفتاب استفاده کنید.',
    ingredients: 'آب، ویتامین C (۱۰٪)، هیالورونیک اسید، ویتامین E' },
  { sku: 'SH-004', name: 'شامپو ترمیم‌کننده', category: 'مو', price: 290, stock: 60, emoji: '🧼', bg: '#e6f3fb',
    brief: 'مناسب موهای آسیب‌دیده و رنگ‌شده',
    description: 'شامپو بدون سولفات با کراتین برای ترمیم و براقی مو.',
    usage: 'روی موی مرطوب ماساژ دهید، ۲ دقیقه بماند و کامل آبکشی کنید.',
    ingredients: 'آب، کراتین، پروتئین ابریشم، روغن آرگان' },
  { sku: 'SS-005', name: 'کرم ضدآفتاب SPF50', category: 'مراقبت پوست', price: 560, stock: 45, emoji: '☀️', bg: '#fff6d6',
    brief: 'محافظت وسیع‌الطیف، بدون چربی',
    description: 'ضدآفتاب سبک با محافظت UVA/UVB، مناسب زیر آرایش.',
    usage: '۱۵ دقیقه قبل از خروج از خانه بزنید و هر ۲ تا ۳ ساعت تجدید کنید.',
    ingredients: 'فیلترهای UV، آب، گلیسیرین، ویتامین E' },
  { sku: 'MK-006', name: 'ماسک صورت', category: 'مراقبت پوست', price: 180, stock: 100, emoji: '🌿', bg: '#e4f4e8',
    brief: 'آبرسان و آرام‌بخش',
    description: 'ماسک ورقه‌ای با عصاره چای سبز برای آبرسانی سریع.',
    usage: 'روی پوست تمیز بگذارید، ۱۵ تا ۲۰ دقیقه صبر کنید و بردارید. نیازی به شستن نیست.',
    ingredients: 'عصاره چای سبز، هیالورونیک اسید، آب' },
  { sku: 'MA-007', name: 'ریمل حجم‌دهنده', category: 'آرایش', price: 260, stock: 70, emoji: '✨', bg: '#efe6fb',
    brief: 'حجم و بلندی، ضدآب',
    description: 'ریمل با برس انحنادار برای حجم و جداسازی مژه‌ها.',
    usage: 'از ریشه به نوک مژه بکشید و در صورت نیاز دو لایه بزنید.',
    ingredients: 'موم زنبور عسل، رنگدانه، پروتئین گندم' },
  { sku: 'PF-008', name: 'ادکلن زنانه', category: 'عطر', price: 1450, stock: 20, emoji: '🌸', bg: '#fde8ee',
    brief: 'رایحه گل و میوه، ماندگاری بالا',
    description: 'عطر با نت‌های گل یاس و میوه‌های استوایی.',
    usage: 'روی نبض مچ و پشت گردن از فاصله ۲۰ سانتی‌متر اسپری کنید.',
    ingredients: 'الکل، اسانس، آب' },
];

(async () => {
  for (const [k, v] of Object.entries({ hold_days: '0', min_payout: '500', shipping_fee: '60', max_total_bps: '1500' }))
    await pool.query('INSERT INTO settings(key,value) VALUES ($1,$2) ON CONFLICT DO NOTHING', [k, v]);

  if (!(await pool.query('SELECT 1 FROM commission_rules WHERE product_id IS NULL')).rowCount)
    for (const [l, bps] of [[1, 500], [2, 300], [3, 200]])
      await pool.query('INSERT INTO commission_rules(level,rate_bps) VALUES ($1,$2)', [l, bps]);

  const mk = async (name: string, email: string, pass: string, code: string, o: { role?: string; sponsor?: number | null; aff?: boolean }) => {
    await pool.query(
      `INSERT INTO users(name,email,password_hash,role,referral_code,sponsor_id,is_affiliate)
       VALUES ($1,$2,$3,$4,$5,$6,$7) ON CONFLICT (email) DO NOTHING`,
      [name, email, await bcrypt.hash(pass, 10), o.role ?? 'customer', code, o.sponsor ?? null, o.aff ?? false]);
    return (await pool.query('SELECT id FROM users WHERE email=$1', [email])).rows[0].id as number;
  };
  await mk('مدیر سایت', ADMIN_EMAIL, ADMIN_PASS, 'ADMIN001', { role: 'admin' });
  const sara = await mk('سارا', 'sara@example.com', DEMO_PASS, 'SARA2410', { aff: true });
  const ali = await mk('علی', 'ali@example.com', DEMO_PASS, 'ALI12345', { aff: true, sponsor: sara });
  const naz = await mk('نازنین', 'nazanin@example.com', DEMO_PASS, 'NAZ12345', { aff: true, sponsor: ali });
  await mk('مشتری آزمایشی', 'buyer@example.com', DEMO_PASS, 'BUYER001', { sponsor: naz });

  mkdirSync(join(process.cwd(), 'uploads'), { recursive: true });
  for (const p of products) {
    await pool.query(
      `INSERT INTO products(sku,name,category,brief,description,usage_instructions,ingredients,price,stock)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (sku) DO NOTHING`,
      [p.sku, p.name, p.category, p.brief, p.description, p.usage, p.ingredients, p.price, p.stock]);
    const id = (await pool.query('SELECT id FROM products WHERE sku=$1', [p.sku])).rows[0].id;
    if (!(await pool.query('SELECT 1 FROM product_images WHERE product_id=$1', [id])).rowCount) {
      const file = `seed-${p.sku}.svg`;
      writeFileSync(join(process.cwd(), 'uploads', file),
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 600"><rect width="600" height="600" fill="${p.bg}"/>` +
        `<text x="300" y="360" font-size="220" text-anchor="middle">${p.emoji}</text></svg>`);
      await pool.query('INSERT INTO product_images(product_id,url) VALUES ($1,$2)', [id, '/uploads/' + file]);
    }
  }

  console.log(`✔ seed done
  ادمین : ${ADMIN_EMAIL} / ${ADMIN_PASS}
  همکاران آزمایشی (رمز ${DEMO_PASS}): sara@example.com ← ali@example.com ← nazanin@example.com ← buyer@example.com (خریدار)
  لینک سارا: /r/SARA2410`);
  await pool.end();
})().catch(e => { console.error(e); process.exit(1); });
