import { Tx } from '../../db';

export interface Ancestor { beneficiary_id: number; lvl: number; is_affiliate: boolean; is_active: boolean }
export interface ItemRow { id: number; product_id: number; net_amount: number; refunded_amount: number; commission_eligible: boolean }

export const getOrder = async (tx: Tx, id: number) =>
  (await tx.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE', [id])).rows[0];

export const getItems = async (tx: Tx, orderId: number): Promise<ItemRow[]> =>
  (await tx.query(
    `SELECT oi.id, oi.product_id, oi.net_amount, oi.refunded_amount, p.commission_eligible
       FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id=$1`, [orderId])).rows;

export const getAncestors = async (tx: Tx, buyerId: number): Promise<Ancestor[]> =>
  (await tx.query(
    `WITH RECURSIVE up AS (
       SELECT id, sponsor_id, 0 AS lvl FROM users WHERE id = $1
       UNION ALL
       SELECT u.id, u.sponsor_id, up.lvl + 1 FROM users u JOIN up ON u.id = up.sponsor_id WHERE up.lvl < 3
     )
     SELECT up.id AS beneficiary_id, up.lvl, u.is_affiliate, u.is_active
       FROM up JOIN users u ON u.id = up.id WHERE up.lvl BETWEEN 1 AND 3 ORDER BY up.lvl`, [buyerId])).rows;

export const getRate = async (tx: Tx, level: number, productId: number): Promise<number> => {
  const r = await tx.query(
    `SELECT rate_bps FROM commission_rules
      WHERE level=$1 AND (product_id=$2 OR product_id IS NULL)
        AND valid_from <= now() AND (valid_to IS NULL OR valid_to > now())
      ORDER BY product_id NULLS LAST, valid_from DESC, id DESC LIMIT 1`, [level, productId]);
  return r.rows[0]?.rate_bps ?? 0;
};

export const insertCommission = (tx: Tx, c: {
  order_id: number; order_item_id: number; beneficiary_id: number; level: number;
  base_amount: number; rate_bps: number; amount: number; approve_after: string | Date;
}) => tx.query(
  `INSERT INTO commissions(order_id,order_item_id,beneficiary_id,level,base_amount,rate_bps,amount,approve_after)
   VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT DO NOTHING`,
  [c.order_id, c.order_item_id, c.beneficiary_id, c.level, c.base_amount, c.rate_bps, c.amount, c.approve_after]);

export const lockDue = async (tx: Tx) =>
  (await tx.query(
    `SELECT id, beneficiary_id, amount FROM commissions
      WHERE status='pending' AND approve_after <= now() FOR UPDATE SKIP LOCKED`)).rows;

export const setStatus = (tx: Tx, id: number, status: string) =>
  tx.query('UPDATE commissions SET status=$2 WHERE id=$1', [id, status]);

export const walletInsert = (tx: Tx, userId: number, amount: number, type: string, refId: number) =>
  tx.query('INSERT INTO wallet_entries(user_id,amount,type,ref_id) VALUES ($1,$2,$3,$4) ON CONFLICT DO NOTHING',
    [userId, amount, type, refId]);

export const commissionsOfItem = async (tx: Tx, itemId: number) =>
  (await tx.query(
    `SELECT id, beneficiary_id, base_amount, rate_bps, amount, status
       FROM commissions WHERE order_item_id=$1 FOR UPDATE`, [itemId])).rows;

export const updateAmount = (tx: Tx, id: number, base: number, amount: number) =>
  tx.query(
    `UPDATE commissions SET base_amount=$2::bigint, amount=$3::bigint,
            status = CASE WHEN $3::bigint <= 0 THEN 'reversed' ELSE status END WHERE id=$1`, [id, base, amount]);

export const addRefund = (tx: Tx, itemId: number, amount: number) =>
  tx.query('UPDATE order_items SET refunded_amount = refunded_amount + $2 WHERE id=$1', [itemId, amount]);

export const rescheduleOrder = (tx: Tx, orderId: number, days: number) =>
  tx.query(
    `UPDATE commissions SET approve_after = now() + make_interval(days => $2)
      WHERE order_id=$1 AND status='pending'`, [orderId, days]);
