import { Tx, getSetting } from '../../db';
import * as repo from './commission.repo';

const bps = (base: number, rate: number) => Math.floor((base * rate) / 10_000);

export const holdDays = async (tx: Tx) => Number(await getSetting(tx, 'hold_days', '14'));

/** بعد از پرداخت قطعی سفارش: ساخت پورسانت‌های pending (ایدمپوتنت). تا قبل از تحویل، approve_after = infinity */
export async function onOrderPaid(orderId: number, tx: Tx) {
  const order = await repo.getOrder(tx, orderId);
  if (!order || !['paid', 'delivered'].includes(order.status)) return;

  const items = (await repo.getItems(tx, orderId)).filter(i => i.commission_eligible);
  const chain = (await repo.getAncestors(tx, order.buyer_id))
    .filter(a => a.beneficiary_id !== order.buyer_id && a.is_affiliate && a.is_active);

  const approveAfter = order.delivered_at
    ? new Date(new Date(order.delivered_at).getTime() + (await holdDays(tx)) * 86_400_000)
    : 'infinity';

  for (const item of items) {
    const base = item.net_amount - item.refunded_amount;
    for (const { beneficiary_id, lvl } of chain) {
      const rate = await repo.getRate(tx, lvl, item.product_id);
      const amount = bps(base, rate);
      if (amount <= 0) continue;
      await repo.insertCommission(tx, {
        order_id: orderId, order_item_id: item.id, beneficiary_id,
        level: lvl, base_amount: base, rate_bps: rate, amount, approve_after: approveAfter,
      });
    }
  }
}

/** بعد از تحویل: شروع مهلت مرجوعی */
export async function onDelivered(orderId: number, tx: Tx) {
  await repo.rescheduleOrder(tx, orderId, await holdDays(tx));
}

export async function approveDue(tx: Tx) {
  const due = await repo.lockDue(tx);
  for (const c of due) {
    await repo.setStatus(tx, c.id, 'approved');
    await repo.walletInsert(tx, c.beneficiary_id, c.amount, 'commission', c.id);
  }
  return due.length;
}

export async function onRefund(orderItemId: number, refundAmount: number, tx: Tx) {
  await repo.addRefund(tx, orderItemId, refundAmount);
  for (const c of await repo.commissionsOfItem(tx, orderItemId)) {
    if (c.status === 'reversed') continue;
    const newBase = Math.max(c.base_amount - refundAmount, 0);
    const newAmount = bps(newBase, c.rate_bps);
    const delta = c.amount - newAmount;
    if (c.status === 'pending') {
      await repo.updateAmount(tx, c.id, newBase, newAmount);
    } else if (delta > 0) {
      await repo.walletInsert(tx, c.beneficiary_id, -delta, 'clawback', c.id);
      await repo.updateAmount(tx, c.id, newBase, newAmount);
    }
  }
}
