import { Router } from 'express';
import { pool, withTx, getSetting } from '../../db';
import { HttpError, wrap, num } from '../../http';
import { requireUser } from '../../middleware/auth';

const r = Router();
r.use(requireUser);

const mask = (n: string) => (n ? n.trim().slice(0, 2) + '***' : '***');

r.get('/summary', wrap(async (req, res) => {
  const uid = req.user!.id;
  const u = (await pool.query('SELECT referral_code, is_affiliate FROM users WHERE id=$1', [uid])).rows[0];
  if (!u.is_affiliate) return res.json({ is_affiliate: false });

  const one = async (sql: string) => (await pool.query(sql, [uid])).rows[0];
  const money = await one(`SELECT
      (SELECT COALESCE(SUM(amount),0) FROM wallet_entries WHERE user_id=$1) AS balance,
      (SELECT COALESCE(SUM(amount),0) FROM commissions WHERE beneficiary_id=$1 AND status='pending') AS pending,
      (SELECT COALESCE(SUM(amount),0) FROM wallet_entries WHERE user_id=$1 AND type='commission') AS earned`);

  const lv = (await pool.query(
    `WITH RECURSIVE d AS (
       SELECT id, 1 AS lvl FROM users WHERE sponsor_id=$1
       UNION ALL SELECT u.id, d.lvl+1 FROM users u JOIN d ON u.sponsor_id=d.id WHERE d.lvl<3)
     SELECT lvl, COUNT(*)::int AS c FROM d GROUP BY lvl`, [uid])).rows;
  const network = [1, 2, 3].map(l => lv.find(x => x.lvl === l)?.c ?? 0);

  const tree = (await pool.query(
    `WITH RECURSIVE d AS (
       SELECT id, name, sponsor_id, 1 AS lvl FROM users WHERE sponsor_id=$1
       UNION ALL SELECT u.id, u.name, u.sponsor_id, d.lvl+1 FROM users u JOIN d ON u.sponsor_id=d.id WHERE d.lvl<3)
     SELECT d.id, d.name, d.sponsor_id, d.lvl,
            (SELECT COALESCE(SUM(oi.net_amount - oi.refunded_amount),0)
               FROM order_items oi JOIN orders o ON o.id=oi.order_id
              WHERE o.buyer_id=d.id AND o.status IN ('paid','delivered')) AS sales
       FROM d ORDER BY d.lvl, d.id`, [uid])).rows.map(t => ({ ...t, name: mask(t.name) }));

  const commissions = (await pool.query(
    `SELECT c.id, c.order_id, c.level, c.base_amount, c.rate_bps, c.amount, c.status, c.approve_after, c.created_at
       FROM commissions c WHERE beneficiary_id=$1 ORDER BY c.id DESC LIMIT 15`, [uid])).rows;
  const wallet = (await pool.query(
    'SELECT id, amount, type, created_at FROM wallet_entries WHERE user_id=$1 ORDER BY id DESC LIMIT 10', [uid])).rows;
  const payouts = (await pool.query(
    'SELECT id, amount, method, status, created_at FROM payouts WHERE user_id=$1 ORDER BY id DESC LIMIT 10', [uid])).rows;
  const min_payout = Number(await getSetting(pool, 'min_payout', '500'));

  res.json({ is_affiliate: true, referral_code: u.referral_code, ...money, network, tree, commissions, wallet, payouts, min_payout });
}));

r.post('/payouts', wrap(async (req, res) => {
  const amount = num(req.body?.amount, 'مبلغ', 1);
  const method = String(req.body?.method ?? '').trim(), account = String(req.body?.account ?? '').trim();
  if (!method || account.length < 3) throw new HttpError(400, 'روش و مشخصات حساب را وارد کنید');

  const id = await withTx(async tx => {
    const u = (await tx.query('SELECT is_affiliate FROM users WHERE id=$1 FOR UPDATE', [req.user!.id])).rows[0];
    if (!u.is_affiliate) throw new HttpError(403, 'شما همکار فروش نیستید');
    const min = Number(await getSetting(tx, 'min_payout', '500'));
    if (amount < min) throw new HttpError(400, `حداقل برداشت ${min} افغانی است`);
    const bal = (await tx.query('SELECT COALESCE(SUM(amount),0) AS b FROM wallet_entries WHERE user_id=$1', [req.user!.id])).rows[0].b;
    if (amount > bal) throw new HttpError(400, 'موجودی کافی نیست');
    const p = (await tx.query('INSERT INTO payouts(user_id,amount,method,account) VALUES ($1,$2,$3,$4) RETURNING id',
      [req.user!.id, amount, method, account])).rows[0];
    await tx.query(`INSERT INTO wallet_entries(user_id,amount,type,ref_id) VALUES ($1,$2,'payout',$3)`, [req.user!.id, -amount, p.id]);
    return p.id;
  });
  res.json({ id });
}));

export default r;
