import { Router } from 'express';
import { pool, withTx, audit, getSetting } from '../../db';
import { HttpError, wrap, num } from '../../http';
import { requireAdmin } from '../../middleware/auth';
import { adminRoutes as productAdmin } from '../catalog/catalog.routes';
import { approveDue, onDelivered, onOrderPaid, onRefund } from '../commission/commission.service';

const r = Router();
r.use(requireAdmin);
r.use(productAdmin); // /products, /images

const rows = async (sql: string, p: any[] = []) => (await pool.query(sql, p)).rows;

r.get('/stats', wrap(async (_req, res) => {
  res.json((await rows(`SELECT
    (SELECT COUNT(*)::int FROM users WHERE is_affiliate) AS affiliates,
    (SELECT COUNT(*)::int FROM users WHERE role='customer') AS customers,
    (SELECT COUNT(*)::int FROM orders) AS orders,
    (SELECT COALESCE(SUM(oi.net_amount-oi.refunded_amount),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id
       WHERE o.status IN ('paid','delivered')) AS sales,
    (SELECT COALESCE(SUM(amount),0) FROM wallet_entries WHERE type='commission') AS commissions_approved,
    (SELECT COALESCE(SUM(amount),0) FROM commissions WHERE status='pending') AS commissions_pending,
    (SELECT COUNT(*)::int FROM payouts WHERE status='requested') AS payouts_open,
    (SELECT COUNT(*)::int FROM fraud_flags WHERE status='open') AS flags_open`))[0]);
}));

// ---------- سفارش‌ها
r.get('/orders', wrap(async (_req, res) => {
  res.json(await rows(
    `SELECT o.id, o.status, o.payment_method, o.total, o.created_at, o.address, o.phone, u.name AS buyer, s.name AS sponsor,
            (SELECT json_agg(json_build_object('id', oi.id, 'name', p.name, 'qty', oi.qty, 'net', oi.net_amount, 'refunded', oi.refunded_amount))
               FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=o.id) AS items,
            (SELECT COALESCE(SUM(amount),0) FROM commissions WHERE order_id=o.id AND status<>'reversed') AS commission_total
       FROM orders o JOIN users u ON u.id=o.buyer_id LEFT JOIN users s ON s.id=u.sponsor_id ORDER BY o.id DESC LIMIT 100`));
}));

r.post('/orders/:id/deliver', wrap(async (req, res) => {
  const id = num(req.params.id, 'id');
  await withTx(async tx => {
    const o = (await tx.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE', [id])).rows[0];
    if (!o) throw new HttpError(404, 'سفارش پیدا نشد');
    if (o.status === 'pending') { // پرداخت در محل: پول هنگام تحویل دریافت می‌شود
      await tx.query(`UPDATE orders SET status='delivered', paid_at=now(), delivered_at=now() WHERE id=$1`, [id]);
      await onOrderPaid(id, tx);
    } else if (o.status === 'paid') {
      await tx.query(`UPDATE orders SET status='delivered', delivered_at=now() WHERE id=$1`, [id]);
      await onDelivered(id, tx);
    } else throw new HttpError(400, 'وضعیت این سفارش قابل تحویل نیست');
    await audit(tx, req.user!.id, 'order.deliver', String(id));
  });
  res.json({ ok: true });
}));

r.post('/orders/:id/refund', wrap(async (req, res) => {
  const id = num(req.params.id, 'id'), itemId = num(req.body?.item_id, 'آیتم', 1);
  await withTx(async tx => {
    const it = (await tx.query(
      `SELECT oi.*, o.status FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.id=$1 AND oi.order_id=$2 FOR UPDATE OF oi`, [itemId, id])).rows[0];
    if (!it) throw new HttpError(404, 'آیتم پیدا نشد');
    const left = it.net_amount - it.refunded_amount;
    if (left <= 0) throw new HttpError(400, 'این آیتم قبلاً مرجوع شده است');
    await onRefund(itemId, left, tx);
    await tx.query('UPDATE products SET stock = stock + $2 WHERE id=$1', [it.product_id, it.qty]);
    const rest = await tx.query('SELECT 1 FROM order_items WHERE order_id=$1 AND net_amount - refunded_amount > 0', [id]);
    if (!rest.rowCount) await tx.query(`UPDATE orders SET status='refunded' WHERE id=$1`, [id]);
    await audit(tx, req.user!.id, 'order.refund', `order ${id} item ${itemId}`);
  });
  res.json({ ok: true });
}));

// ---------- پورسانت‌ها
r.get('/commissions', wrap(async (_req, res) => {
  res.json(await rows(
    `SELECT c.id, c.order_id, c.level, c.base_amount, c.rate_bps, c.amount, c.status, c.approve_after, u.name AS beneficiary
       FROM commissions c JOIN users u ON u.id=c.beneficiary_id ORDER BY c.id DESC LIMIT 200`));
}));

r.post('/commissions/approve-due', wrap(async (req, res) => {
  const n = await withTx(async tx => { const c = await approveDue(tx); await audit(tx, req.user!.id, 'commissions.approve', String(c)); return c; });
  res.json({ approved: n });
}));

// ---------- نرخ‌ها و تنظیمات
r.get('/rules', wrap(async (_req, res) => {
  const cur = await rows(
    `SELECT DISTINCT ON (level) level, rate_bps FROM commission_rules
      WHERE product_id IS NULL AND valid_from <= now() AND (valid_to IS NULL OR valid_to > now())
      ORDER BY level, valid_from DESC, id DESC`);
  const history = await rows(
    `SELECT level, rate_bps, valid_from, valid_to FROM commission_rules WHERE product_id IS NULL ORDER BY id DESC LIMIT 12`);
  res.json({ rates: [1, 2, 3].map(l => cur.find(c => c.level === l)?.rate_bps ?? 0), history,
             cap_bps: Number(await getSetting(pool, 'max_total_bps', '1500')) });
}));

r.put('/rules', wrap(async (req, res) => {
  const rates: number[] = (req.body?.rates ?? []).map((x: unknown) => num(x, 'نرخ'));
  if (rates.length !== 3 || rates.some(x => x > 10000)) throw new HttpError(400, 'نرخ سه سطح لازم است');
  await withTx(async tx => {
    const cap = Number(await getSetting(tx, 'max_total_bps', '1500'));
    if (rates.reduce((a, b) => a + b, 0) > cap) throw new HttpError(400, `مجموع نرخ‌ها نباید از ${cap / 100}٪ بیشتر شود`);
    await tx.query('UPDATE commission_rules SET valid_to=now() WHERE product_id IS NULL AND valid_to IS NULL');
    for (let l = 1; l <= 3; l++) await tx.query('INSERT INTO commission_rules(level,rate_bps) VALUES ($1,$2)', [l, rates[l - 1]]);
    await audit(tx, req.user!.id, 'rules.update', rates.map(x => x / 100 + '%').join(' / '));
  });
  res.json({ ok: true });
}));

const SETTING_KEYS = ['hold_days', 'min_payout', 'shipping_fee', 'max_total_bps'];
r.get('/settings', wrap(async (_req, res) => {
  const o: Record<string, string> = {};
  for (const r of await rows('SELECT key, value FROM settings')) o[r.key] = r.value;
  res.json(o);
}));
r.put('/settings', wrap(async (req, res) => {
  await withTx(async tx => {
    for (const k of SETTING_KEYS) {
      if (req.body?.[k] === undefined) continue;
      const v = num(req.body[k], k);
      await tx.query('INSERT INTO settings(key,value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value', [k, String(v)]);
    }
    await audit(tx, req.user!.id, 'settings.update', JSON.stringify(req.body));
  });
  res.json({ ok: true });
}));

// ---------- برداشت‌ها
r.get('/payouts', wrap(async (_req, res) => {
  res.json(await rows(
    `SELECT p.*, u.name AS user_name,
            (SELECT COALESCE(SUM(amount),0) FROM wallet_entries WHERE user_id=p.user_id) AS balance
       FROM payouts p JOIN users u ON u.id=p.user_id ORDER BY (p.status='requested') DESC, p.id DESC LIMIT 100`));
}));
r.post('/payouts/:id/:action', wrap(async (req, res) => {
  const id = num(req.params.id, 'id'), approve = req.params.action === 'approve';
  if (!approve && req.params.action !== 'reject') throw new HttpError(400, 'عملیات نامعتبر');
  await withTx(async tx => {
    const p = (await tx.query('SELECT * FROM payouts WHERE id=$1 FOR UPDATE', [id])).rows[0];
    if (!p || p.status !== 'requested') throw new HttpError(400, 'این درخواست قابل بررسی نیست');
    await tx.query('UPDATE payouts SET status=$2 WHERE id=$1', [id, approve ? 'paid' : 'rejected']);
    if (!approve) await tx.query(`INSERT INTO wallet_entries(user_id,amount,type,ref_id) VALUES ($1,$2,'adjust',$3)`, [p.user_id, p.amount, id]);
    await audit(tx, req.user!.id, approve ? 'payout.approve' : 'payout.reject', String(id));
  });
  res.json({ ok: true });
}));

// ---------- همکاران و ضدتقلب
r.get('/users', wrap(async (req, res) => {
  const q = req.query.q ? `%${String(req.query.q)}%` : null;
  res.json(await rows(
    `SELECT u.id, u.name, u.email, u.role, u.is_affiliate, u.is_active, u.created_at, s.name AS sponsor,
            (SELECT COUNT(*)::int FROM users d WHERE d.sponsor_id=u.id) AS direct,
            (SELECT COALESCE(SUM(oi.net_amount-oi.refunded_amount),0) FROM order_items oi JOIN orders o ON o.id=oi.order_id
              WHERE o.buyer_id=u.id AND o.status IN ('paid','delivered')) AS own_sales
       FROM users u LEFT JOIN users s ON s.id=u.sponsor_id
      WHERE ($1::text IS NULL OR u.name ILIKE $1 OR u.email ILIKE $1) ORDER BY u.id DESC LIMIT 100`, [q]));
}));
r.post('/users/:id/active', wrap(async (req, res) => {
  const id = num(req.params.id, 'id');
  if (id === req.user!.id) throw new HttpError(400, 'نمی‌توانید حساب خودتان را تعلیق کنید');
  await pool.query('UPDATE users SET is_active=$2 WHERE id=$1', [id, !!req.body?.active]);
  await audit(pool, req.user!.id, req.body?.active ? 'user.activate' : 'user.suspend', String(id));
  res.json({ ok: true });
}));

r.get('/flags', wrap(async (_req, res) => {
  res.json(await rows(
    `SELECT f.*, u.name AS user_name FROM fraud_flags f LEFT JOIN users u ON u.id=f.user_id
      ORDER BY (f.status='open') DESC, f.id DESC LIMIT 100`));
}));
r.post('/flags/:id/resolve', wrap(async (req, res) => {
  await pool.query(`UPDATE fraud_flags SET status='resolved' WHERE id=$1`, [num(req.params.id, 'id')]);
  res.json({ ok: true });
}));

r.get('/audit', wrap(async (_req, res) => {
  res.json(await rows(`SELECT a.*, u.name AS admin FROM audit_log a LEFT JOIN users u ON u.id=a.admin_id ORDER BY a.id DESC LIMIT 100`));
}));

export default r;
