import { Router } from 'express';
import multer from 'multer';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { pool, audit, getSetting } from '../../db';
import { HttpError, wrap, num } from '../../http';
import { requireAdmin } from '../../middleware/auth';

export const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const EXT: Record<string, string> = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (_r, f, cb) => cb(null, crypto.randomBytes(8).toString('hex') + EXT[f.mimetype]),
  }),
  limits: { fileSize: 5 * 1024 * 1024, files: 8 },
  fileFilter: (_r, f, cb) => cb(null, f.mimetype in EXT),
});

// ---------- عمومی
export const publicRoutes = Router();

publicRoutes.get('/shipping', wrap(async (_req, res) => {
  res.json({ shipping_fee: Number(await getSetting(pool, 'shipping_fee', '0')) });
}));

publicRoutes.get('/categories', wrap(async (_req, res) => {
  res.json((await pool.query('SELECT DISTINCT category FROM products WHERE is_active ORDER BY 1')).rows.map(r => r.category));
}));

publicRoutes.get('/products', wrap(async (req, res) => {
  const cat = req.query.category ? String(req.query.category) : null;
  const rows = (await pool.query(
    `SELECT p.id, p.name, p.category, p.brief, p.price, p.stock,
            (SELECT url FROM product_images WHERE product_id=p.id ORDER BY sort, id LIMIT 1) AS image
       FROM products p WHERE p.is_active AND ($1::text IS NULL OR p.category=$1) ORDER BY p.id DESC`, [cat])).rows;
  res.json(rows);
}));

publicRoutes.get('/products/:id', wrap(async (req, res) => {
  const p = (await pool.query('SELECT * FROM products WHERE id=$1 AND is_active', [num(req.params.id, 'id')])).rows[0];
  if (!p) throw new HttpError(404, 'محصول پیدا نشد');
  p.images = (await pool.query('SELECT id, url FROM product_images WHERE product_id=$1 ORDER BY sort, id', [p.id])).rows;
  res.json(p);
}));

// ---------- مدیریت محصول (ادمین)
export const adminRoutes = Router();
adminRoutes.use(requireAdmin);

const TEXT = ['sku', 'name', 'category', 'brief', 'description', 'usage_instructions', 'ingredients'] as const;

function readBody(b: any, partial: boolean) {
  const out: Record<string, unknown> = {};
  for (const k of TEXT) if (b[k] !== undefined) out[k] = String(b[k]).trim();
  if (b.price !== undefined) out.price = num(b.price, 'قیمت');
  if (b.stock !== undefined) out.stock = num(b.stock, 'موجودی');
  if (b.commission_eligible !== undefined) out.commission_eligible = !!b.commission_eligible;
  if (b.is_active !== undefined) out.is_active = !!b.is_active;
  if (!partial && (!out.name || !out.sku || out.price === undefined)) throw new HttpError(400, 'نام، کد کالا و قیمت الزامی است');
  return out;
}

adminRoutes.get('/products', wrap(async (_req, res) => {
  res.json((await pool.query(
    `SELECT p.*, (SELECT COUNT(*)::int FROM product_images WHERE product_id=p.id) AS image_count,
            (SELECT url FROM product_images WHERE product_id=p.id ORDER BY sort, id LIMIT 1) AS image
       FROM products p ORDER BY p.id DESC`)).rows);
}));

adminRoutes.get('/products/:id', wrap(async (req, res) => {
  const p = (await pool.query('SELECT * FROM products WHERE id=$1', [num(req.params.id, 'id')])).rows[0];
  if (!p) throw new HttpError(404, 'محصول پیدا نشد');
  p.images = (await pool.query('SELECT id, url FROM product_images WHERE product_id=$1 ORDER BY sort, id', [p.id])).rows;
  res.json(p);
}));

adminRoutes.post('/products', wrap(async (req, res) => {
  const d = readBody(req.body ?? {}, false);
  const cols = Object.keys(d);
  try {
    const r = await pool.query(
      `INSERT INTO products(${cols.join(',')}) VALUES (${cols.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING *`, Object.values(d));
    await audit(pool, req.user!.id, 'product.create', r.rows[0].name);
    res.json(r.rows[0]);
  } catch (e: any) {
    if (e.code === '23505') throw new HttpError(409, 'این کد کالا قبلاً ثبت شده است');
    throw e;
  }
}));

adminRoutes.put('/products/:id', wrap(async (req, res) => {
  const d = readBody(req.body ?? {}, true);
  const cols = Object.keys(d);
  if (!cols.length) throw new HttpError(400, 'چیزی برای ویرایش نیست');
  const r = await pool.query(
    `UPDATE products SET ${cols.map((c, i) => `${c}=$${i + 2}`).join(',')} WHERE id=$1 RETURNING *`,
    [num(req.params.id, 'id'), ...Object.values(d)]);
  if (!r.rows[0]) throw new HttpError(404, 'محصول پیدا نشد');
  await audit(pool, req.user!.id, 'product.update', r.rows[0].name);
  res.json(r.rows[0]);
}));

// حذف = غیرفعال‌سازی (سفارش‌های قبلی به محصول وابسته‌اند)
adminRoutes.delete('/products/:id', wrap(async (req, res) => {
  await pool.query('UPDATE products SET is_active=false WHERE id=$1', [num(req.params.id, 'id')]);
  await audit(pool, req.user!.id, 'product.deactivate', String(req.params.id));
  res.json({ ok: true });
}));

adminRoutes.post('/products/:id/images', upload.array('images', 8), wrap(async (req, res) => {
  const id = num(req.params.id, 'id');
  const files = (req.files as Express.Multer.File[]) ?? [];
  if (!files.length) throw new HttpError(400, 'فایل تصویر (jpg/png/webp تا ۵ مگابایت) انتخاب نشده است');
  let sort = (await pool.query('SELECT COALESCE(MAX(sort),0)+1 AS s FROM product_images WHERE product_id=$1', [id])).rows[0].s;
  for (const f of files) {
    await pool.query('INSERT INTO product_images(product_id,url,sort) VALUES ($1,$2,$3)', [id, '/uploads/' + f.filename, sort++]);
  }
  await audit(pool, req.user!.id, 'product.images.add', `${id} (+${files.length})`);
  res.json({ added: files.length });
}));

adminRoutes.post('/images/:id/cover', wrap(async (req, res) => {
  await pool.query(
    `UPDATE product_images SET sort = (SELECT COALESCE(MIN(sort),0)-1 FROM product_images
       WHERE product_id=(SELECT product_id FROM product_images WHERE id=$1)) WHERE id=$1`, [num(req.params.id, 'id')]);
  res.json({ ok: true });
}));

adminRoutes.delete('/images/:id', wrap(async (req, res) => {
  const r = await pool.query('DELETE FROM product_images WHERE id=$1 RETURNING url', [num(req.params.id, 'id')]);
  const url: string | undefined = r.rows[0]?.url;
  if (url?.startsWith('/uploads/')) fs.promises.unlink(path.join(UPLOAD_DIR, path.basename(url))).catch(() => {});
  res.json({ ok: true });
}));
