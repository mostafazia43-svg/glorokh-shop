import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { pool, withTx, flag } from '../../db';
import { HttpError, wrap } from '../../http';
import { requireUser, setAuthCookie } from '../../middleware/auth';

const r = Router();
const newCode = () => crypto.randomBytes(5).toString('hex').toUpperCase().slice(0, 8);
const pub = (u: any) => ({ id: u.id, name: u.name, email: u.email, role: u.role, is_affiliate: u.is_affiliate, referral_code: u.referral_code });

r.post('/register', wrap(async (req, res) => {
  const { name, email, password, ref } = req.body ?? {};
  if (typeof name !== 'string' || name.trim().length < 2) throw new HttpError(400, 'نام را وارد کنید');
  if (typeof email !== 'string' || !/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, 'ایمیل نامعتبر است');
  if (typeof password !== 'string' || password.length < 8) throw new HttpError(400, 'رمز عبور حداقل ۸ کاراکتر باشد');

  const refCode = String(ref || req.cookies?.ref || '').trim().toUpperCase();
  const hash = await bcrypt.hash(password, 10);

  const user = await withTx(async tx => {
    let sponsor: number | null = null;
    if (refCode) {
      const s = await tx.query('SELECT id FROM users WHERE referral_code=$1 AND is_active', [refCode]);
      sponsor = s.rows[0]?.id ?? null;
    }
    let u;
    try {
      u = (await tx.query(
        `INSERT INTO users(name,email,password_hash,referral_code,sponsor_id,signup_ip)
         VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
        [name.trim(), email.trim().toLowerCase(), hash, newCode(), sponsor, req.ip ?? null])).rows[0];
    } catch (e: any) {
      if (e.code === '23505') throw new HttpError(409, 'این ایمیل قبلاً ثبت شده است');
      throw e;
    }
    if (req.ip) {
      const c = await tx.query(
        `SELECT COUNT(*)::int AS c FROM users WHERE signup_ip=$1 AND created_at > now() - interval '24 hours'`, [req.ip]);
      if (c.rows[0].c >= 3) await flag(tx, 'duplicate_ip', 'medium', u.id, `${c.rows[0].c} حساب با یک IP در ۲۴ ساعت`);
    }
    return u;
  });

  setAuthCookie(res, user);
  res.json(pub(user));
}));

r.post('/login', wrap(async (req, res) => {
  const { email, password } = req.body ?? {};
  const u = (await pool.query('SELECT * FROM users WHERE email=$1', [String(email ?? '').trim().toLowerCase()])).rows[0];
  if (!u || !(await bcrypt.compare(String(password ?? ''), u.password_hash))) throw new HttpError(401, 'ایمیل یا رمز عبور اشتباه است');
  if (!u.is_active) throw new HttpError(403, 'حساب شما تعلیق شده است');
  setAuthCookie(res, u);
  res.json(pub(u));
}));

r.post('/logout', (_req, res) => { res.clearCookie('token'); res.json({ ok: true }); });

r.get('/me', wrap(async (req, res) => {
  if (!req.user) return res.json(null);
  const u = (await pool.query(
    `SELECT u.*, s.name AS sponsor_name FROM users u LEFT JOIN users s ON s.id=u.sponsor_id WHERE u.id=$1`, [req.user.id])).rows[0];
  res.json({ ...pub(u), sponsor_name: u.sponsor_name });
}));

// نام معرفی که کوکی ۳۰ روزه‌اش در مرورگر هست
r.get('/referrer', wrap(async (req, res) => {
  const code = String(req.cookies?.ref ?? '');
  const s = code ? (await pool.query('SELECT name FROM users WHERE referral_code=$1 AND is_active', [code])).rows[0] : null;
  res.json({ name: s?.name ?? null, code: s ? code : null });
}));

r.post('/affiliate/join', requireUser, wrap(async (req, res) => {
  await pool.query('UPDATE users SET is_affiliate=true WHERE id=$1', [req.user!.id]);
  res.json({ ok: true });
}));

export default r;
