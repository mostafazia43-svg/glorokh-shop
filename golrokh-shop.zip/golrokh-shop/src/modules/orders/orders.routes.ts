import { Router } from 'express';
import { pool, withTx, getSetting, flag } from '../../db';
import { HttpError, wrap, num } from '../../http';
import { requireUser } from '../../middleware/auth';
import { onOrderPaid } from '../commission/commission.service';

const r = Router();
r.use(requireUser);

r.post('/', wrap(async (req, res) => {
  const { items, address, phone, refCode, payment_method } = req.body ?? {};
  if (!Array.isArray(items) || !items.length) throw new HttpError(400, 'سبد خرید خالی است');
  if (typeof address !== 'string' || address.trim().length < 5) throw new HttpError(400, 'آدرس را وارد کنید');
  if (typeof phone !== 'string' || phone.trim().length < 7) throw new HttpError(400, 'شماره تماس را وارد کنید');
  const method = payment_method === 'cod' ? 'cod' : 'online_test';

  // یکی‌کردن ردیف‌های تکراری
  const qty = new Map<number, number>();
  for (const it of items) {
    const id = num(it.product_id, 'محصول', 1), q = num(it.qty, 'تعداد', 1);
    if (q > 50) throw new HttpError(400, 'حداکثر تعداد هر محصول ۵۰ است');
    qty.set(id, (qty.get(id) ?? 0) + q);
  }

  const out = await withTx(async tx => {
    const buyer = (await tx.query('SELECT id, referral_code, sponsor_id FROM users WHERE id=$1 FOR UPDATE', [req.user!.id])).rows[0];

    // کد معرف: فقط برای خریدار بدون معرف و قبل از اولین خرید قطعی
    const code = String(refCode || req.cookies?.ref || '').trim().toUpperCase();
    if (code) {
      if (code === buyer.referral_code) {
        await flag(tx, 'self_referral', 'high', buyer.id, 'تلاش برای استفاده از کد معرف خود');
      } else if (!buyer.sponsor_id) {
        const prev = await tx.query(`SELECT 1 FROM orders WHERE buyer_id=$1 AND status IN ('paid','delivered')`, [buyer.id]);
        const sp = (await tx.query('SELECT id FROM users WHERE referral_code=$1 AND is_active', [code])).rows[0];
        if (!prev.rowCount && sp) {
          const cyc = await tx.query(
            `WITH RECURSIVE a AS (
               SELECT id, sponsor_id FROM users WHERE id=$1
               UNION ALL SELECT u.id, u.sponsor_id FROM users u JOIN a ON u.id=a.sponsor_id)
             SELECT 1 FROM a WHERE id=$2`, [sp.id, buyer.id]);
          if (!cyc.rowCount) await tx.query('UPDATE users SET sponsor_id=$2 WHERE id=$1', [buyer.id, sp.id]);
        }
      }
    }

    const products = (await tx.query('SELECT id, name, price FROM products WHERE id = ANY($1) AND is_active', [[...qty.keys()]])).rows;
    if (products.length !== qty.size) throw new HttpError(400, 'یکی از محصولات موجود نیست');

    const shipping = Number(await getSetting(tx, 'shipping_fee', '0'));
    const lines = products.map((p: any) => ({ id: p.id, name: p.name, q: qty.get(p.id)!, net: p.price * qty.get(p.id)! }));
    const total = lines.reduce((a, l) => a + l.net, 0) + shipping;

    const paid = method === 'online_test'; // در نسخه آزمایشی پرداخت آنلاین بلافاصله موفق فرض می‌شود
    const o = (await tx.query(
      `INSERT INTO orders(buyer_id,status,payment_method,address,phone,paid_at,shipping,total)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [buyer.id, paid ? 'paid' : 'pending', method, address.trim(), phone.trim(), paid ? new Date() : null, shipping, total])).rows[0];

    for (const l of lines) {
      const st = await tx.query('UPDATE products SET stock = stock - $2 WHERE id=$1 AND stock >= $2', [l.id, l.q]);
      if (!st.rowCount) throw new HttpError(400, `موجودی «${l.name}» کافی نیست`);
      await tx.query('INSERT INTO order_items(order_id,product_id,qty,net_amount) VALUES ($1,$2,$3,$4)', [o.id, l.id, l.q, l.net]);
    }
    if (paid) await onOrderPaid(o.id, tx);
    return { id: o.id, total, status: paid ? 'paid' : 'pending' };
  });
  res.json(out);
}));

r.get('/mine', wrap(async (req, res) => {
  res.json((await pool.query(
    `SELECT o.id, o.status, o.total, o.created_at,
            (SELECT json_agg(json_build_object('name', p.name, 'qty', oi.qty, 'net', oi.net_amount))
               FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=o.id) AS items
       FROM orders o WHERE o.buyer_id=$1 ORDER BY o.id DESC`, [req.user!.id])).rows);
}));

export default r;
